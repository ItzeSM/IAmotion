import Foundation
import GoogleGenerativeAI

final class ChatResponder {
    static let shared = ChatResponder()

    private let model: GenerativeModel

    private init() {
        guard let path = Bundle.main.path(forResource: "GenerativeAI-Info", ofType: "plist"),
              let dict = NSDictionary(contentsOfFile: path),
              let apiKey = dict["API_KEY"] as? String else {
            fatalError("GEMINI_API_KEY no encontrada en GenerativeAI-Info.plist")
        }

        model = GenerativeModel(name: "gemini-2.5-pro", apiKey: apiKey)
    }

    enum Tone: String, CaseIterable, Codable {
        case empathetic, motivational, relaxing
    }

    var tone: Tone = .empathetic
    
    func detectarEmocion(_ texto: String) -> String {
        let lower = texto.lowercased()
        if lower.contains("triste") { return "Triste" }
        if lower.contains("feliz") { return "Feliz" }
        if lower.contains("enoj") || lower.contains("molest") { return "Enojado" }
        if lower.contains("miedo") || lower.contains("asust") { return "Miedo" }
        if lower.contains("sorpr") { return "Sorpresa" }
        if lower.contains("relajad") { return "Relajado" }
        if lower.contains("emocionad") { return "Emoción" }
        return "Neutral"
    }


    func respond(to message: String) async -> String {
        do {
            let response = try await model.generateContent(message)
            return response.text ?? "No se pudo interpretar la respuesta de Gemini 😕."
        } catch {
            print("❌ Error al comunicarse con Gemini:", error)
            return "Error al comunicarse con Gemini 😔."
        }
    }
}

