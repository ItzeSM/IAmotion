//
//  ChatEmotionWrapper.swift
//  IAmotion2
//
//  Created by Itzel Santiago Maldonado on 28/10/25.
//

import SwiftUI

struct ChatEmotionWrapper: View {
    @ObservedObject var viewModel: ChatViewModel
    @State private var currentEmotion: String = "Feliz"
    @State private var showBreathing = false
   
    
    var body: some View {
        ZStack {
            // Fondo dinámico según emoción
            backgroundColor(for: currentEmotion)
                .ignoresSafeArea()
            
            if currentEmotion == "Feliz" {
                       ConfettiView()
                           .ignoresSafeArea()
                           .transition(.opacity)
                           .animation(.easeInOut, value: currentEmotion)
                   }


            VStack(spacing: 10) {
                // Encabezado con emoción
                HStack {
                    Image(systemName: emotionIcon(for: currentEmotion))
                        .font(.system(size: 36))
                        .foregroundStyle(.white)
                    Text(currentEmotion)
                        .font(.title2)
                        .bold()
                        .foregroundStyle(.white)
                    Spacer()
                    EmotionIndicatorView(emotion: currentEmotion)
                }
                .padding()
                
                // Botón para borrar chat
                  HStack {
                      Spacer()
                      Button(action: {
                          viewModel.messages.removeAll()
                      }) {
                          Label("Borrar chat", systemImage: "trash.fill")
                              .foregroundColor(.red)
                              .padding(8)
                              .background(Color.white.opacity(0.2))
                              .cornerRadius(8)
                      }
                      Spacer()
                  }
                // Botón de llamada de emergencia
                Button(action: {
                    if let url = URL(string: "tel://911"), UIApplication.shared.canOpenURL(url) {
                        UIApplication.shared.open(url)
                    }
                }) {
                    Label("Emergencia", systemImage: "phone.fill")
                        .foregroundColor(.white)
                        .padding(8)
                        .background(Color.red.opacity(0.8))
                        .cornerRadius(8)
                }
                .padding(.vertical, 5)

                
                // Botón para respirar
                             Button(action: { showBreathing = true }) {
                                 Label("Respira", systemImage: "wind")
                                     .foregroundColor(.white)
                                     .padding(8)
                                     .background(Color.blue.opacity(0.7))
                                     .cornerRadius(8)
                             }
                             .padding(.vertical, 5)
                             .sheet(isPresented: $showBreathing) {
                                 BreathingView() // <-- Aquí se muestra la pantalla de respiración
                             }

                             if viewModel.isLoading {
                                 LoadingGearView()
                                     .padding()
                             }

                // ChatView original
                ChatView(viewModel: viewModel)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(12)
                    .padding(.horizontal)
            }
        }
        .onChange(of: viewModel.messages.count) { _ in
            detectEmotion()
        }
        .animation(.easeInOut, value: currentEmotion)
    }

    private func detectEmotion() {
           guard let lastMessage = viewModel.messages.last?.text.lowercased() else { return }

           if lastMessage.contains("triste") { currentEmotion = "Triste" }
           else if lastMessage.contains("feliz") { currentEmotion = "Feliz" }
           else if lastMessage.contains("enoj") || lastMessage.contains("molest") { currentEmotion = "Enojado" }
           else if lastMessage.contains("miedo") || lastMessage.contains("asust") { currentEmotion = "Miedo" }
           else if lastMessage.contains("sorpr") { currentEmotion = "Sorpresa" }
           else if lastMessage.contains("relajad") { currentEmotion = "Relajado" }
           else if lastMessage.contains("emocionad") { currentEmotion = "Emoción" }
           else { currentEmotion = "Neutral" }
       }

       private func backgroundColor(for emotion: String) -> LinearGradient {
           switch emotion {
           case "Triste": return LinearGradient(colors: [.blue.opacity(0.6), .purple.opacity(0.4)], startPoint: .top, endPoint: .bottom)
           case "Feliz": return LinearGradient(colors: [.yellow.opacity(0.6), .pink.opacity(0.5)], startPoint: .top, endPoint: .bottom)
           case "Enojado": return LinearGradient(colors: [.red.opacity(0.7), .orange.opacity(0.5)], startPoint: .top, endPoint: .bottom)
           case "Relajado": return LinearGradient(colors: [.green.opacity(0.5), .teal.opacity(0.4)], startPoint: .top, endPoint: .bottom)
           case "Emoción": return LinearGradient(colors: [.purple.opacity(0.6), .pink.opacity(0.5)], startPoint: .top, endPoint: .bottom)
           case "Sorpresa": return LinearGradient(colors: [.orange.opacity(0.6), .yellow.opacity(0.5)], startPoint: .top, endPoint: .bottom)
           case "Miedo": return LinearGradient(colors: [.gray.opacity(0.5), .black.opacity(0.3)], startPoint: .top, endPoint: .bottom)
           default: return LinearGradient(colors: [.gray.opacity(0.3), .black.opacity(0.2)], startPoint: .top, endPoint: .bottom)
           }
       }

       private func emotionIcon(for emotion: String) -> String {
           switch emotion {
           case "Triste": return "cloud.drizzle.fill"
           case "Feliz": return "sun.max.fill"
           case "Enojado": return "flame.fill"
           case "Relajado": return "leaf.fill"
           case "Emoción": return "sparkles"
           case "Sorpresa": return "exclamationmark.circle.fill"
           case "Miedo": return "eye.fill"
           default: return "questionmark.circle.fill"
           }
       }
   }

   struct EmotionIndicatorView: View {
       let emotion: String

       var body: some View {
           Circle()
               .trim(from: 0, to: emotionLevel(for: emotion))
               .stroke(Color.white, lineWidth: 5)
               .frame(width: 40, height: 40)
               .rotationEffect(.degrees(-90))
               .overlay(Text("💓"))
       }

       private func emotionLevel(for emotion: String) -> CGFloat {
           switch emotion {
           case "Triste": return 0.3
           case "Enojado": return 0.6
           case "Relajado": return 0.8
           case "Feliz": return 1.0
           case "Sorpresa": return 0.7
           case "Miedo": return 0.4
           case "Emoción": return 0.9
           default: return 0.5
           }
       }
   }
