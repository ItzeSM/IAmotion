//
//  IAmotion2App.swift
//  IAmotion2
//
//  Created by Itzel Santiago Maldonado on 28/10/25.
//

import SwiftUI

@main
struct IAmotion2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
