import SwiftUI
import Combine

final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var inputText: String = ""
    @Published var tone: ChatResponder.Tone = .empathetic {
        didSet { ChatResponder.shared.tone = tone }
    }
    @Published var isLoading: Bool = false
    init() {
        messages = StorageManager.shared.load()
    }

    func sendUserMessage() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        let userMsg = ChatMessage(text: trimmed, isUser: true, emotion: ChatResponder.shared.detectarEmocion(trimmed))
        messages.append(userMsg)
        StorageManager.shared.save(messages: messages)
        inputText = ""
        
        isLoading = true

        Task {
            let responseText = await ChatResponder.shared.respond(to: userMsg.text)
            await MainActor.run {
                let botMsg = ChatMessage(text: responseText, isUser: false, emotion: nil)
                self.messages.append(botMsg)
                StorageManager.shared.save(messages: self.messages)
                
                self.isLoading = false
            }
        }
    }
}
