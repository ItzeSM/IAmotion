import Foundation

final class StorageManager {
    static let shared = StorageManager()
    private init() {}

    private let filename = "messages.json"

    private var fileURL: URL {
        let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return folder.appendingPathComponent(filename)
    }

    func save(messages: [ChatMessage]) {
        do {
            let data = try JSONEncoder().encode(messages)
            try data.write(to: fileURL)
        } catch {
            print("Error guardando mensajes:", error)
        }
    }

    func load() -> [ChatMessage] {
        do {
            let data = try Data(contentsOf: fileURL)
            return try JSONDecoder().decode([ChatMessage].self, from: data)
        } catch {
            return []
        }
    }
}
