//
//  BreathingView.swift
//  IAmotion2
//
//  Created by Itzel Santiago Maldonado on 28/10/25.
//

import SwiftUI
import Combine

struct BreathingView: View {
    @State private var scale: CGFloat = 0.5
    @State private var phase = "Inhala"

    let timer = Timer.publish(every: 4, on: .main, in: .common).autoconnect() // 4 segundos por fase

    var body: some View {
        VStack(spacing: 40) {
            Text(phase)
                .font(.largeTitle)
                .bold()
                .foregroundColor(.white)

            Circle()
                .fill(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 200, height: 200)
                .scaleEffect(scale)
                .animation(.easeInOut(duration: 4), value: scale)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .onReceive(timer) { _ in
            switch phase {
            case "Inhala":
                phase = "Mantén"
                scale = 1.0
            case "Mantén":
                phase = "Exhala"
                scale = 0.5
            case "Exhala":
                phase = "Inhala"
                scale = 1.0
            default:
                phase = "Inhala"
                scale = 1.0
            }
        }
    }
}

struct BreathingView_Previews: PreviewProvider {
    static var previews: some View {
        BreathingView()
    }
}
