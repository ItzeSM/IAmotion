//
//  ConfettiView.swift
//  IAmotion2
//
//  Created by Itzel Santiago Maldonado on 28/10/25.
//

import SwiftUI

struct ConfettiView: View {
    @State private var animate = false
    let colors: [Color] = [.red, .green, .blue, .yellow, .pink, .orange]
    let numberOfPieces = 20
    
    var body: some View {
        ZStack {
            ForEach(0..<numberOfPieces, id: \.self) { i in
                Circle()
                    .fill(colors.randomElement()!)
                    .frame(width: 8, height: 8)
                    .position(x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                              y: animate ? UIScreen.main.bounds.height + 10 : -10)
                    .animation(
                        .easeIn(duration: Double.random(in: 1.5...3)),
                        value: animate
                    )
            }
        }
        .onAppear {
            animate = true
        }
    }
}

struct ConfettiView_Previews: PreviewProvider {
    static var previews: some View {
        ConfettiView()
    }
}
