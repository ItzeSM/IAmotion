//
//  LoadingGearView.swift
//  IAmotion2
//
//  Created by Itzel Santiago Maldonado on 28/10/25.
//

import SwiftUI


struct LoadingGearView: View {
    @State private var rotate = false

    var body: some View {
        Image(systemName: "gearshape.fill")
            .resizable()
            .frame(width: 40, height: 40)
            .foregroundColor(.white)
            .rotationEffect(.degrees(rotate ? 360 : 0))
            .animation(.linear(duration: 1).repeatForever(autoreverses: false), value: rotate)
            .onAppear { rotate = true }
    }
}

struct LoadingGearView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingGearView()
            .background(Color.black)
    }
}
