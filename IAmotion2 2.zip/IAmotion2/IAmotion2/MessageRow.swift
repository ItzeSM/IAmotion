import SwiftUI

struct MessageRow: View {
    let msg: ChatMessage

    var body: some View {
        HStack {
            if msg.isUser { Spacer() }
            Text(msg.text)
                .padding()
                .background(msg.isUser ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                .foregroundColor(msg.isUser ? .white : .primary)
                .cornerRadius(12)
                .frame(maxWidth: UIScreen.main.bounds.width * 0.75, alignment: .leading)
            if !msg.isUser { Spacer() }
        }
        .padding(msg.isUser ? .leading : .trailing, 40)
    }
}
