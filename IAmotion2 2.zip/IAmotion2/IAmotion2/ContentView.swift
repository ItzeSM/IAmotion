import SwiftUI

struct ContentView: View {
    @StateObject private var vm = ChatViewModel()

    var body: some View {
       
            ChatEmotionWrapper(viewModel: vm)
                .navigationTitle("IAmotion2")
                .navigationBarTitleDisplayMode(.inline)
        }
    }



#Preview {
    ContentView()
}

